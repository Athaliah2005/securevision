"""
Database models — User, AccessLog, AllowedIP
"""
from datetime import datetime
from flask_login import UserMixin
from werkzeug.security import generate_password_hash, check_password_hash
from app import db, login_manager


class User(UserMixin, db.Model):
    __tablename__ = "users"

    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(64), unique=True, nullable=False, index=True)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password_hash = db.Column(db.String(256), nullable=False)
    role = db.Column(db.String(20), default="viewer")          # admin | operator | viewer
    is_active = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    last_login = db.Column(db.DateTime, nullable=True)

    logs = db.relationship("AccessLog", backref="user", lazy="dynamic")

    def set_password(self, password: str) -> None:
        self.password_hash = generate_password_hash(password)

    def check_password(self, password: str) -> bool:
        return check_password_hash(self.password_hash, password)

    def is_admin(self) -> bool:
        return self.role == "admin"

    def __repr__(self) -> str:
        return f"<User {self.username}>"


class AccessLog(db.Model):
    """Immutable audit trail of every login attempt."""
    __tablename__ = "access_logs"

    id = db.Column(db.Integer, primary_key=True)
    timestamp = db.Column(db.DateTime, default=datetime.utcnow, nullable=False, index=True)
    username_attempt = db.Column(db.String(64), nullable=False)
    ip_address = db.Column(db.String(45), nullable=False)          # IPv4 or IPv6
    user_agent = db.Column(db.String(256), nullable=True)
    outcome = db.Column(db.String(20), nullable=False)             # success | fail_pw | blocked_ip | blocked_user
    alert_sent = db.Column(db.Boolean, default=False)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=True)

    def __repr__(self) -> str:
        return f"<AccessLog {self.timestamp} {self.ip_address} {self.outcome}>"


class AllowedIP(db.Model):
    """
    Dynamic IP allow-list managed by admins at runtime.
    ◄── SECURITY LOGIC: rows in this table gate access to the entire platform.
    """
    __tablename__ = "allowed_ips"

    id = db.Column(db.Integer, primary_key=True)
    ip_address = db.Column(db.String(45), unique=True, nullable=False)
    label = db.Column(db.String(128), nullable=True)              # e.g. "Office Router"
    added_by = db.Column(db.String(64), nullable=True)
    added_at = db.Column(db.DateTime, default=datetime.utcnow)
    is_active = db.Column(db.Boolean, default=True)

    def __repr__(self) -> str:
        return f"<AllowedIP {self.ip_address}>"


@login_manager.user_loader
def load_user(user_id: str):
    return db.session.get(User, int(user_id))
