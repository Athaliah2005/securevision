# 🔒 SecureVision

**Production-ready security monitoring platform built with Flask, OpenCV, and GEDSI-aligned UI.**

---

## Features

| Area | Details |
|---|---|
| **Backend** | Python / Flask with SQLAlchemy ORM |
| **Hardware** | OpenCV MJPEG streaming (webcam + RTSP/CCTV) |
| **Database** | SQLite (dev) or PostgreSQL (prod) — full access audit log |
| **Security** | IP allow-list gate, brute-force rate limiting, session hardening |
| **Alerts** | SMTP email + Telegram Bot on unauthorised access |
| **UI** | Tailwind CSS, GEDSI-compliant (WCAG AA contrast, ARIA, screen-reader ready) |

---

## Quick Start

```bash
# 1. Clone and enter
git clone https://github.com/yourorg/securevision.git
cd securevision

# 2. Create virtual environment
python -m venv .venv && source .venv/bin/activate   # Windows: .venv\Scripts\activate

# 3. Install dependencies
pip install -r requirements.txt

# 4. Configure environment
cp .env.example .env
# Edit .env — set SECRET_KEY, ALLOWED_IPS, and notification credentials

# 5. Seed database (creates admin user + localhost allow-list)
python scripts/seed.py

# 6. Run
python run.py
```

Open **http://127.0.0.1:5000** — log in with `admin` / `ChangeMe123!` (change immediately).

---

## Project Structure

```
securevision/
├── app/
│   ├── __init__.py              # App factory
│   ├── models/__init__.py       # User, AccessLog, AllowedIP
│   ├── routes/
│   │   ├── auth.py              # ◄ SECURITY: IP gate + login logic
│   │   ├── dashboard.py
│   │   ├── camera.py            # MJPEG stream endpoint
│   │   ├── admin.py             # IP & user management
│   │   └── errors.py
│   ├── services/
│   │   ├── security.py          # ◄ SECURITY: allow-list + alert dispatch
│   │   └── camera.py            # OpenCV thread-safe stream
│   ├── templates/
│   │   ├── base.html            # GEDSI base layout
│   │   ├── auth/login.html
│   │   ├── dashboard/{index,camera,admin}.html
│   │   └── errors/{403,404,429,500}.html
│   └── static/
├── config/settings.py           # ◄ SECURITY: all secrets via env vars
├── scripts/seed.py
├── .env.example                 # Safe template — commit this
├── .env                         # ◄ NEVER COMMIT — listed in .gitignore
├── .gitignore
├── requirements.txt
└── run.py
```

---

## 🔐 Security-Sensitive Files

The following files/sections contain **security logic** and must be protected:

| File | What it protects |
|---|---|
| `.env` | All secrets — **never commit** |
| `config/settings.py` | Reads secrets; defines `ALLOWED_IPS` |
| `app/services/security.py` | IP allow-list logic + alert credential usage |
| `app/routes/auth.py` | Login gate — IP check before password check |
| `app/models/__init__.py` | `AllowedIP` table — rows gate platform access |

---

## 📹 Camera Configuration

**Webcam (default):** `CAMERA_SOURCE=0`

**IP Camera / CCTV via RTSP:**
```
CAMERA_SOURCE=rtsp://username:password@192.168.1.100:554/stream1
```
> ⚠ Store RTSP credentials in `.env`, never hardcoded or in version control.

---

## 🌐 GEDSI Compliance

This platform follows **Gender Equality, Disability, and Social Inclusion** principles:

- **High contrast** colour palette (WCAG AA minimum 4.5:1 ratio)
- **Skip navigation** link — first focusable element for keyboard users
- **Explicit `<label>` elements** on all form fields (no placeholder-only labels)
- **ARIA attributes** — `aria-required`, `aria-describedby`, `aria-live`, `aria-label`, `role`
- **Screen-reader announcements** — flash messages use `role="alert"` + `aria-live="assertive"`
- **Table captions** with `<caption>` and `scope` attributes for data tables
- **Inclusive language** — no stigmatising or exclusionary copy
- **Password visibility toggle** with accessible `aria-pressed` state

---

## Production Deployment

```bash
# Using Gunicorn
gunicorn -w 4 -b 0.0.0.0:8000 "app:create_app('production')"
```

Set `SESSION_COOKIE_SECURE=True` (requires HTTPS) and use a reverse proxy (Nginx/Caddy).

---

## Licence

MIT — See `LICENSE` for details.
